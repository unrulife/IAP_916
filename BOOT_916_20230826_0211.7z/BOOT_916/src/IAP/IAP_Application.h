#ifndef _IAP_APPLICATION_H_
#define _IAP_APPLICATION_H_

#include <stdint.h>

void IAP_Application_Init(void);

#endif


