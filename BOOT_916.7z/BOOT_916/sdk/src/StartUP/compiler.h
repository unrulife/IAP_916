#warning This file is obsoleted
#warning Please update settings of compiler search paths: remove StartUP; add StartUP/ing918
#include "StartUP/ing918/compiler.h"
