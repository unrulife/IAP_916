#ifndef _IAP_916_H_
#define _IAP_916_H_

#include <stdint.h>
#include "IAP_FLASH_MAP.H"

void IAP_Init(void);

#endif


